
from dataclasses import field
from typing import List, Optional
import marshmallow
from marshmallow import fields
import marshmallow_dataclass
from marshmallow_dataclass import dataclass

@dataclass
class Card:
    suit : str
    number_value : int = field(metadata =  { 'data_key' : 'numberValue' })
    string_value : str = field(metadata =  { 'data_key' : 'stringValue' })

CardSchema = marshmallow_dataclass.class_schema(Card)
    
@dataclass
class Player:
    id : str
    type : str
    is_eliminated : bool = field(metadata =  { 'data_key' : 'isEliminated' })

PlayerSchema = marshmallow_dataclass.class_schema(Player)

@dataclass
class TurnState:
    event : str
    payload : dict 

TurnStateSchema = marshmallow_dataclass.class_schema(TurnState)
  
@dataclass
class PlayedCard:
    card : Card 
    is_correct : bool = field(metadata =  { 'data_key' : 'isCorrect' })
    is_white_marker : bool = field(metadata =  { 'data_key' : 'isWhiteMarker' })
    black_marker : Optional[dict] = field(metadata =  { 'data_key' : 'blackMarker' })
    player : str

PlayedCardSchema = marshmallow_dataclass.class_schema(PlayedCard)

@dataclass
class Game:
    players: List[Player]
    oracle_id: str = field(metadata =  { 'data_key' : 'oracleId' })
    prophet_id: Optional[str] = field(metadata =  { 'data_key' : 'prophetId' })
    current_player: Optional[str] = field(metadata =  { 'data_key' : 'currentPlayer' })
    current_state: TurnState = field(metadata =  { 'data_key' : 'currentState' })
    is_sudden_death: bool = field(metadata =  { 'data_key' : 'isSuddenDeath' })
    timeline: List[PlayedCard]

GameSchema = marshmallow_dataclass.class_schema(Game)
