
import requests

from eleusis_client import PreGame
from eleusis_client import PreGameSchema
from eleusis_client import JwtResponse
from eleusis_client import JwtResponseSchema
from eleusis_client import Game
from eleusis_client import GameSchema
from eleusis_client import CardSchema

class ApiClient(object):
    
    def __init__(self, api_url):
        self._api_url = None

        if api_url is not None:
            self._api_url = api_url

        self._json_token = None

    @property
    def api_url(self):
        return self._api_url

    @api_url.setter
    def api_url(self,value):
        self._api_url = value.strip('/')

    def _get_base_headers(self):
        headers = {}
        if self._json_token is not None:
            headers['Authorization'] = f'Bearer {self._json_token}'
        return headers
    
    def is_logged_in(self):
        return _json_token is None

    def register(self, username, password):
        url = f'{self.api_url}/api/Login/Create'
        login = {'userName' : username, 'password' : password}
        result = requests.post(url,json=login)
        if result.status_code != 200:
            return False
        serializer = JwtResponseSchema()
        print(result.text)
        obj = serializer.loads(result.text)
        self._json_token = obj.jwt
        return True
                    
    def login(self, username, password):
        url = f'{self.api_url}/api/Login/'
        login = {'userName' : username, 'password' : password}
        result = requests.post(url,json=login)
        if result.status_code != 200:
            return False
        serializer = JwtResponseSchema()
        print(result.text)
        obj = serializer.loads(result.text)
        self._json_token = obj.jwt
        return True


    def create_game(self,isOracle):
        url = f'{self.api_url}/api/Eleusis/'
        data = {'iamOracle' : isOracle}
        result = requests.post(url, headers=self._get_base_headers(), json=data)
        if result.status_code == 401 :
            print("You aren't authorized, login again")
            return None
        elif result.status_code != 200:
            print("Got an error back from the api ",result.text)
            return None
        else:
            serializer = PreGameSchema()
            return serializer.loads(result.text)
    
    def get_game(self, pregame):
        return self.get_game_by_id(pregame.game_id)

    def get_game_by_id(self, game_id):
        url = f'{self.api_url}/api/Eleusis/{game_id}'
        result = requests.get(url, headers=self._get_base_headers())
        if result.status_code == 404:
            print("Game not found")
            return None
        elif result.status_code != 200:
            print("Got an error back from the api ", result.status_code, result.text)
        else:
            serializer = PreGameSchema()
            return serializer.loads(result.text)

    def add_player_bot(self, game_id):
        url = f'{self.api_url}/api/Eleusis/{game_id}/bots/player'
        result = requests.post(url, headers=self._get_base_headers(), data="")
        if result.status_code != 200:
            print("Error from the server ", result.status_code, result.text)
            return None
        else:            
            serializer = PreGameSchema()
            return serializer.loads(result.text)

    def add_oracle_bot(self, game_id):
        url = f'{self.api_url}/api/Eleusis/{game_id}/bots/oracle'
        result = requests.post(url, headers=self._get_base_headers(), data="")
        if result.status_code != 200:
            print("Error from the server ", result.status_code, result.text)
            return None
        else:            
            serializer = PreGameSchema()
            return serializer.loads(result.text)

    def start_game(self, game_id):
        url = f'{self.api_url}/api/Eleusis/{game_id}/start'
        result = requests.post(url, headers=self._get_base_headers(), data="")
        if result.status_code != 200:
            print("Error from the server ", result.status_code, resUlt.text)
            return None
        else:
            serializer = GameSchema()
            return serializer.loads(result.text)

    def get_game_state(self, game_id):
        url = f'{self.api_url}/api/Eleusis/{game_id}/inprogress'
        result = requests.get(url, headers=self._get_base_headers())
        if result.status_code != 200:
            print("Error from the server ", result.status_code, result.text)
            return None
        else:
            try:
                serializer = GameSchema()
                return serializer.loads(result.text)
            except(exn):
                print("error processing results: ", exn, result.text)
        
    def get_hand(self, game_id):
        url = f'{self.api_url}/api/Eleusis/{game_id}/hand'
        result = requests.get(url, headers=self._get_base_headers())
        if result.status_code != 200:
            print("Error from the server ", result.status_code, result.text)
            return None
        else:
            serializer = CardSchema(many=True)
            return serializer.loads(result.text)

    def play_cards(self,game_id, cards):
        url = f'{self.api_url}/api/Eleusis/{game_id}/play/cards'
        serializer = CardSchema(many=True)
        headers =  self._get_base_headers()
        headers['Content-Type'] =  'application/json'
        result = requests.post(url, headers=headers, data = serializer.dumps(cards))
        if result.status_code != 200:
            print("Error from the server ", result.status_code, result.text)
            return None
        else:
            try:
                serializer = GameSchema()
                return serializer.loads(result.text)
            except(exn):
                print("error processing results: ", exn, result.text)

    def play_no_cards(self, game_id):
        url = f'{self.api_url}/api/Eleusis/{game_id}/play/noGoodCards'
        result = requests.post(url, headers=self._get_base_headers(), json='')
        if result.status_code != 200:
            print("Error from the server ", result.status_code, result.text)
            return None
        else:
            try:
                serializer = GameSchema()
                return serializer.loads(result.text)
            except(exn):
                print("error processing results: ", exn, result.text)        
