from dataclasses import dataclass, field
from typing import List, Optional

@dataclass
class JwtResponse:
    jwt : str = field(metadata = {'data_key' : "jWT" })

import marshmallow_dataclass
                      
JwtResponseSchema = marshmallow_dataclass.class_schema(JwtResponse)
