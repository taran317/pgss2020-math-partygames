# coding: utf-8

from dataclasses import dataclass, field
from typing import List, Optional



@dataclass
class PreGame:
    game_id : str = field(metadata = { 'data_key' : "gameId" })
    owner_id : str = field(metadata =  { 'data_key' : 'ownerId' })
    oracle : Optional[str]
    players : List[str] 


import marshmallow_dataclass

PreGameSchema = marshmallow_dataclass.class_schema(PreGame)
